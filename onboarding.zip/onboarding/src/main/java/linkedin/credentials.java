package linkedin;

public class credentials {

	public static String client_id="781v2ovwhpmy7y";
	public static String redirect_url="http://localhost:8080/linkedIn";
	public static String client_secret="Q0LUU8ENVfugQw3w";
	
}
